(ns ding
  (:require
   [table.core :as table]
   [cissy.registry :as register]
   [taoensso.timbre :as timbre]
   [cissy.helpers :as helpers])
  (:import (java.util HashMap)))

(def data [["Name" "Age" "City"]
           ["Alice" 30 "New York"]
           ["Bob" 25 "Los Angeles"]
           ["Charlie" 35 "Chicago"]])
(def ascii-table (table/table data))

(register/defnode ding [task-node-execution-info]
  (Thread/sleep 2000)
  (timbre/info "发送消息")
  (println ascii-table)
  (helpers/curr-node-done task-node-execution-info)
  ["ding! dong!"])

